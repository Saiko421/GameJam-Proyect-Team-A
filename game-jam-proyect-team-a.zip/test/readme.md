# AUTORIA: Johan (Programador)
El contenido dentro de esta carpeta [test] es unicamente para pruebas y prototipado,
no se debe tomar en cuenta a la hora de la evaluación final del juego.
Gracias.
