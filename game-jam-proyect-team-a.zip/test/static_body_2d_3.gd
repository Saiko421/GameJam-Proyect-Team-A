extends StaticBody2D

func interact() -> void:
	print("interactuado.")
	global_position.y -= 16
