## Componente que permite decibir daño.
## [En desarrollo]
class_name TakeDamage extends Component

@export var HurtBox: Area2D

func _ready() -> void:
	HurtBox.area_entered.connect(_activate)

func _activate(_area: Area2D):
	if get_parent().has_method("take_damage"):
		if "damage" in _area.get_parent():
			get_parent().take_damege(_area.get_parent().damage)
