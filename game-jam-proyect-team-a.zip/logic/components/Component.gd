@abstract
## Clase base de la mayoria de los componentes personalizados.
class_name Component extends Node
