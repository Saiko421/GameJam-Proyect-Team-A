## Componente que permite la interacción del jugador con el entorno.
## Posee 4 areas apuntando a las 4 direcciones, al pulsar la tecla
class_name Interactor extends Component

@export_group("Detect Areas")
@export var left_area: Area2D
@export var right_area: Area2D
@export var up_area: Area2D
@export var down_area: Area2D
@export_group("Variables")
@export var action: String = ""

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed(action):
		_try_interact()

func _try_interact() -> void:
	var dir = Vector2.ZERO; var interaction_area: Area2D
	if "last_direction" in get_parent(): dir = get_parent().last_direction
	else: return
	match dir:
		Vector2.UP: interaction_area = up_area
		Vector2.DOWN: interaction_area = down_area
		Vector2.LEFT: interaction_area = left_area
		Vector2.RIGHT: interaction_area = right_area
	var interactables: Array[Area2D] = interaction_area.get_overlapping_areas()
	if interactables.is_empty(): return
	var target: Area2D = interactables[0]
	if target.has_method("interact"): target.interact()
	elif target.get_parent().has_method("interact"): target.get_parent().interact()
