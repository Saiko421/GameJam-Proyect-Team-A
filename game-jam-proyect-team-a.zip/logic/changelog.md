# AUTORIA: Johan

# Inicio del proyecto en Godot Engine 4.7 [15/10/202_]
> Se creó la escena del personaje con texturas provicionales
> Se implementó un sistema "Tile-based Movement" en 4 direcciones con una regilla de 16x16 para todos los elementos del juego.

[ Implementaciones tecnicas: 
	> El InputMap se consolidó con teclas personalizadas para unificar la experiencia en PC y Movil de base.
	> "Input_up", "Input_left", "Input_down" e "Input_right" se llaman con W-A-S-D respectivamente.
	> "Input_accept" e "Input_back", corresponden a teclas de Aceptar (A) o Denegar (B) respectivamente.

	> Las capas de Colisiones fisicas se nombraron para diferencias las distintas interacciones con el jugador.
	> "Envolopment" para Tiles y ambiente estático.
	> "Player" para el jugador.
	> "Interactable" para objetos interactuables o NPC.
	> "Damage" para regiones que le causen daño al jugador.
	
	> Las capas de Renderizado se nombraron como:
	> "Envolopment", "Player", "Items", "Enemies"
]
