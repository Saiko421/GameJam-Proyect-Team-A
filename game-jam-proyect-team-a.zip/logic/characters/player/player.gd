## Clase unica, utilizada para el jugador controlado.
## Tipo de movimiento: TopDown en 4 direcciones.
## Movimiento "Basado en tiles" como en la GameBoy.
class_name Player extends Entity

# == PROPIEDADES ==
## Vida actual del jugador.
@export var current_live: int = 10
## Maximo de vida del jugador.
@export var max_live: int = 10
## Ultima dirección del personaje.
var last_direction: Vector2 = Vector2.DOWN


# == FUNCIONES ==

## Flujo principal.
func _physics_process(_delta):
	if is_moving: return
	if _get_input_move() != Vector2.ZERO:
		last_direction = _get_input_move()
		move(_get_input_move())
		


## Función para recibir daño
func take_damage(amount: int) -> void: #Interfaz IDamage
	self.current_live -= amount
	# reproducir animación.
	

## Esta función devuekve un Vector2 con una unica dirección: a la que
## se dirige el jugador, en PC con [kbd]ASDW[/kbd], en Movil con el JoyStrick.
func _get_input_move() -> Vector2:
	var dir: Vector2 = Vector2.ZERO;
	dir.y = Input.get_axis("ui_up", "ui_down");
	dir.x = Input.get_axis("ui_left", "ui_right");
	if abs(dir.y) > abs(dir.x):
		if dir.y > 0: dir = Vector2.DOWN;
		elif dir.y < 0: dir = Vector2.UP;
	elif abs(dir.y) < abs(dir.x):
		if dir.x < 0: dir = Vector2.LEFT;
		elif dir.x > 0: dir = Vector2.RIGHT;
	return dir;
	
