@abstract
## Clase base abstracta, utilizada para el elementos moviles.
## Tipo de movimiento: TopDown en 4 direcciones.
## Movimiento "Basado en tiles" como en la GameBoy.
class_name Entity extends CharacterBody2D


# == PROPIEDADES ==

## Establece la distancia en pixeles de una casilla a otra para el movimiento retro.
const TILE_SIZE: int = 16
## Es el tiempo en segundos que tarda en dar un paso de una casilla a otra.
@export var speed_step: float = 0.2
## Variable para registrar si el jugador se está moviendo.
var is_moving: bool = false
## Referencia al RayCast que detecta paredes para anticipar el movimiento.
@export var proximity_ray: RayCast2D


# == FUNCIONES ==

## Función encargada de mover al jugador una casilla por vez a una
## única dirección dada por [param dir], a una distancia fija [member TILE_SIZE],
## a una velocidad variable [member speed_step].
func move(dir: Vector2):
	proximity_ray.target_position = dir * TILE_SIZE
	proximity_ray.force_raycast_update() # Actualizar detección del RayCast
	# Si no hay nada enfrente, se avanza con una interpolación lineal.
	if not proximity_ray.is_colliding():
		is_moving = true
		var target_pos = global_position + (dir * TILE_SIZE)
		var tween = create_tween()
		tween.tween_property(self, "global_position", target_pos, speed_step).set_trans(Tween.TRANS_LINEAR)
		tween.finished.connect(func(): is_moving = false)
